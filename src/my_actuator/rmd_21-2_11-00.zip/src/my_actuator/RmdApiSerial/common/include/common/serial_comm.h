/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file serial_comm.h
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

#ifndef __COMMON_SERIAL_COMM_H__
#define __COMMON_SERIAL_COMM_H__

#include <string>

#include <CppLinuxSerial/SerialPort.hpp>
using namespace mn::CppLinuxSerial;

class SerialCommunication
{
private:
    /* data */
public:
    SerialCommunication();
    SerialCommunication(SerialPort &serialPort);

    SerialCommunication(std::string &port, unsigned int baudrate, unsigned int timeout);
    ~SerialCommunication();

    void serial_init();

    void serial_shutdown();

    std::string send_serial_data(const std::string &data);
    // void receive_data(const std::string &data);

    std::string port_;
    unsigned int baudrate_;
    unsigned int timeout_;
    // static SerialPort serialPort_;
    SerialPort serialPort_;
    std::string receive_data_;
};

#endif