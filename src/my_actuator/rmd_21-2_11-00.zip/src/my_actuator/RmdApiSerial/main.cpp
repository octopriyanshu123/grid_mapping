/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file main.cpp
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

// #include "rmd/x10_api_base.h"
// #include "x10/x10_api.h"
#include "rmd/x10_api.h"

#include <iostream>
#include <unistd.h>

int main()
{

    std::cout << "####################################\n";
    std::cout << "I am here in main.cpp!\n";
    std::cout << "####################################\n";

    // X10ApiBase x10;
    // x10.rmdX10_init();
    // x10.Motor_read_pid(0x01);

    X10ApiSerial *xobj;
    xobj = new X10ApiSerial();

    // xobj.rmdX10_init();
    // xobj.Motor_read_pid(0x1);
    // xobj.speedControl(0x1, 10000);
    // sleep(5);
    // xobj.speedControl(0x1, 00);

    xobj->rmdX10_init();
    xobj->Motor_read_pid(0x1);
    // xobj->speedControl(0x1, 3000);
    // sleep(15);
    // xobj->speedControl(0x1, 00);
    uint32_t i = 0;
    uint16_t data;
    while (1)
    {
        xobj->speedControl(0x1, 2000 + i);
        xobj->Motor_state2(0x1);
        

        if (i > 10000)
        {
            sleep(5);
            break;
        }
        i += 30;
        sleep(1);
    }
    xobj->Motor_stop(0x1);

    return 0;
}
