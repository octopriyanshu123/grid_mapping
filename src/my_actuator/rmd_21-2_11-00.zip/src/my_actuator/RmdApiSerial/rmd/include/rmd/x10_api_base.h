/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file x10_api_base.h
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

#ifndef __BASE_X10_API_BASE_H__
#define __BASE_X10_API_BASE_H__

#include "x10_register.h"
#include "crc16.h"
#include "serial_comm.h"

#include <stdint.h>
#include <string>

class X10ApiBase
{
private:
    /* data */
    std::string RS485_send_driver(uint8_t id_, uint8_t F_Length, uint8_t *F_buff);

protected:
    uint8_t id_;
    X10_REG x10_reg_;
    SerialCommunication serial_;
    Crc crc_;
    std::string send_data_;
    std::string receive_data_;

public:
    X10ApiBase(/* args */);
    ~X10ApiBase();

    // void RS485_mode(t_RS485 *F_RS485);
    // void DRIVER_RS485_ERROR_DELAY(t_RS485 *F_RS485);
    // void DRIVER_signal_data_clean(void);
    // uint8_t DRIVER_read_RS485_START(t_RS485 *F_RS485);
    // void signal_driver(uint8_t F_data);
    // void signal_diaplay(t_signal_data *F_signal_data, uint8_t *F_able, uint8_t F_length);
    // uint8_t DRIVER_read_signal_state(void);
    // void DRIVER_set_signal_state(uint8_t F_state);
    // uint8_t *DRIVER_signal_data(void);
    void Crc_check(uint8_t* DATA);

    void rmdX10_init();

    void Motor_read_pid(uint8_t id_);
    void Write_pid_RAM(uint8_t id_, uint8_t CurrKP, uint8_t CurrKI, uint8_t SpdKP, uint8_t SpdKI, uint8_t PosKP, uint8_t PosKI);
    void Write_pid_ROM(uint8_t id_, uint8_t CurrKP, uint8_t CurrKI, uint8_t SpdKP, uint8_t SpdKI, uint8_t PosKP, uint8_t PosKI);
    void Read_Accel(uint8_t id_);
    void Write_Accel(uint8_t id_, uint8_t index, unsigned int Accel);
    void Motor_now_place_data(uint8_t id_);
    void Motor_code_place_data(uint8_t id_);
    void Read_code_zero_place(uint8_t id_);
    void Write_code_zero_ROM(uint8_t id_, unsigned int F_Speed);
    void Write_NOWcode_zero_ROM(uint8_t id_);
    void Motor_motorAngle_many(uint8_t id_);
    void Motor_state1(uint8_t id_);
    void Motor_state2(uint8_t id_);
    void Motor_state3(uint8_t id_);
    void Motor_clock(uint8_t id_);
    void Motor_stop(uint8_t id_);
    void Motor_torque(uint8_t id_, unsigned short iqControl);
    void speedControl(uint8_t id_,  int speed);
    void Motor_torque_control(uint8_t id_, unsigned int angleControl);
    void Motor_torque_place(uint8_t id_, unsigned short maxSpeed, unsigned int angleControl);
    void speed_control_place(uint8_t id_, unsigned short maxSpeed, unsigned int angleControl);
    void Motor_add(uint8_t id_, unsigned short maxSpeed, unsigned int angleControl);
    void Motor_mode(uint8_t id_);
    void Motor_power(uint8_t id_);
    void Motor_reset(uint8_t id_);
    void OPEN_RlyCtrlRslt(uint8_t id_);
    void CLOSE_RlyCtrlRslt(uint8_t id_);
    void Motor_time(uint8_t id_);
    void Motor_edition(uint8_t id_);
    void Motor_comm_time(uint8_t id_, unsigned int CanRecvTime_MS);
    void Motor_baudrate(uint8_t id_, uint8_t baudrate);
    void Motor_model(uint8_t id_);
    void Motor_function(uint8_t id_, uint8_t index, unsigned int Value);
    void Motor_RS485ID(uint8_t id_, unsigned char wReadWriteFlag, unsigned char CANID);
};

#endif
