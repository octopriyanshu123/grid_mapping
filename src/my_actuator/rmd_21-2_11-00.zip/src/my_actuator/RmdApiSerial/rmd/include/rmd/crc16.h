/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file crc16.h
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

#ifndef __COMMON_CRC16_H__
#define __COMMON_CRC16_H__

#include <stdint.h>

class Crc
{
private:
    /* data */

public:
    Crc(/* args */);
    ~Crc();

    uint16_t crc16(uint8_t *ptr, uint16_t DataLen);
    
};

#endif