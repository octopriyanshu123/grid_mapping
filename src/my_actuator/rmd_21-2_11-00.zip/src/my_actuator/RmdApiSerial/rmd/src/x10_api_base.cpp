/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file x10_api_base.cpp
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

#include <iostream>
#include "rmd/x10_api_base.h"

X10ApiBase::X10ApiBase(/* args */)
{
}

X10ApiBase::~X10ApiBase()
{
}

void X10ApiBase::rmdX10_init()
{
    std::cout << "I am here in rmdX10_init() of x10_api_base\n";
    serial_.serial_init();
}

void X10ApiBase::Crc_check(uint8_t *DATA)
{
    uint16_t T_modbus = 0;
    T_modbus = crc_.crc16(DATA, RS485_MAX - 2);
    DATA[RS485_MAX - 2] = (uint8_t)T_modbus;
    DATA[RS485_MAX - 1] = (uint8_t)(T_modbus >> 8);
}

std::string X10ApiBase::RS485_send_driver(uint8_t F_ID, uint8_t F_Length, uint8_t *F_buff)
{
    uint8_t T_Num = 3;
    // uint16_t T_modbus = 0;

    uint8_t DATA[RS485_MAX] = {0};

    DATA[0] = 0x3e;
    DATA[1] = F_ID;
    DATA[2] = F_Length;

    for (T_Num = 3; T_Num < (RS485_MAX - 2); ++T_Num)
    {
        DATA[T_Num] = F_buff[T_Num - 3];
    }

    // T_modbus = crc_.crc16(DATA, RS485_MAX - 2);

    // DATA[RS485_MAX - 2] = (uint8_t)T_modbus;
    // DATA[RS485_MAX - 1] = (uint8_t)(T_modbus >> 8);

    Crc_check(DATA);

    std::string s = "";
    for (int i = 0; i < RS485_MAX; i++)
    {
        s += DATA[i];
    }

    return s;
}

void X10ApiBase::Motor_read_pid(uint8_t id_)

{
    receive_data_ = "";
    send_data_ = RS485_send_driver(id_, 8, x10_reg_.a_Motor_read_pid);
    receive_data_ = serial_.send_serial_data(send_data_);

    // test
    uint8_t data_arr[RS485_MAX];

    std::cout << "read data: ";
    for (int i = 0; i < RS485_MAX; i++)
    {
        data_arr[i] = (int)receive_data_[i];
        std::cout << "0x" << (int)data_arr[i] << "  ";
    }
    uint8_t currKP = data_arr[5];
    uint8_t currKI = data_arr[6];
    uint8_t spdKP = data_arr[7];
    uint8_t spdKI = data_arr[8];
    uint8_t posKP = data_arr[9];
    uint8_t posKI = data_arr[10];

    printf("\nread PID data:");
    printf("\ncurrKP : %u\n", currKP);
    printf("currKI : %u\n", currKI);
    printf("spdKP  : %u\n", spdKP);
    printf("spdKI  : %u\n", spdKI);
    printf("posKP  : %u\n", posKP);
    printf("posKI  : %u\n", posKI);
    printf("------------------------\n");
}

void X10ApiBase::speedControl(uint8_t id_, int speed)

{
    x10_reg_.a_speedControl[4] = speed;
    x10_reg_.a_speedControl[5] = speed >> 8;
    x10_reg_.a_speedControl[6] = speed >> 16;
    x10_reg_.a_speedControl[7] = speed >> 24;

    receive_data_ = "";
    send_data_ = RS485_send_driver(id_, 8, x10_reg_.a_speedControl);
    receive_data_ = serial_.send_serial_data(send_data_);
    uint8_t receive_data[RS485_MAX];
    for (int i = 0; i < RS485_MAX; i++)
    {
        receive_data[i] = (int)receive_data_[i];
    }
    // if (receive_data[1] == 0x3E && receive_data[2] == id_ && receive_data[3] == 8)
    // {
    //     return 1;
    // }
    // else
    // {
    //     return -1;
    // }
    // // Crc_check(receive_data);

    // return 0;
}

void X10ApiBase::Motor_stop(uint8_t id_)
{
    receive_data_ = "";
    send_data_ = RS485_send_driver(id_, 8, x10_reg_.a_Motor_stop);
    receive_data_ = serial_.send_serial_data(send_data_);

    uint8_t receive_data[RS485_MAX];
    for (int i = 0; i < RS485_MAX; i++)
    {
        receive_data[i] = (int)receive_data_[i];
    }

    // if (receive_data[1] == 0x3E && receive_data[2] == id_ && receive_data[3] == 8)
    // {
    //     return 1;
    // }
    // else
    // {
    //     return -1;
    // }

    // return 0;
}

void X10ApiBase::Motor_state2(uint8_t id_)
{
    receive_data_ = "";
    send_data_ = RS485_send_driver(id_, 8, x10_reg_.a_Motor_state2);
    receive_data_ = serial_.send_serial_data(send_data_);

    uint8_t receive_data[RS485_MAX];
    for (int i = 0; i < RS485_MAX; i++)
    {
        receive_data[i] = (int)receive_data_[i];
    }

    // if (receive_data[1] == 0x3E && receive_data[2] == id_ && receive_data[3] == 8)
    // {
    //     return 1;
    // }
    // else
    // {
    //     return -1;
    // }

    // return data_arr;
}
