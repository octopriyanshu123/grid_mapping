/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved. 
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * 
 * 
 * @file serial_comm.cpp
 * @author Vaibhav 
 * @brief 
 * @date 2023-02-17
 * 
 * 
 */

#include "rmd/serial_comm.h"


SerialCommunication::SerialCommunication()
{
    port_ = "/dev/crawler";
}

SerialCommunication::SerialCommunication(SerialPort &serialPort)
{
    port_ = "/dev/crawler";
    serialPort_ = serialPort;
}

SerialCommunication::SerialCommunication(std::string &port, unsigned int baudrate, unsigned int timeout)
{
    timeout_ = timeout;
    // port_ = port;
    port_ = "/dev/crawler";
}

SerialCommunication::~SerialCommunication()
{
    serialPort_.Close();
}

void SerialCommunication::serial_init()
{   
    
    serialPort_ = SerialPort(port_, BaudRate::B_115200, NumDataBits::EIGHT, Parity::NONE, NumStopBits::ONE);
    serialPort_.SetTimeout(100); // Block for up to 100ms to receive data
    serialPort_.Open();
}

void SerialCommunication::serial_shutdown()
{
    serialPort_.Close();
}

std::string SerialCommunication::send_serial_data(const std::string &data)
{
    receive_data_ = "";
    serialPort_.Write(data);
    serialPort_.Read(receive_data_);
    return receive_data_;
}
