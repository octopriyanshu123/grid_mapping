/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file x10_api.cpp
 * @author Vaibhav
 * @brief
 * @date 2023-02-18
 *
 *
 */

#include "rmd/x10_api.h"

X10ApiSerial::X10ApiSerial(/* args */)
{
}

X10ApiSerial::~X10ApiSerial()
{
}

void X10ApiSerial::rmdX10_init()
{
    std::cout << "I am here in rmdX10_init() of x10_api\n";
    x10_api_base_.rmdX10_init();
}

void X10ApiSerial::Motor_read_pid(uint8_t id_)
{
    std::cout << "I am here in Motor_read_pid() of x10_api\n";
    x10_api_base_.Motor_read_pid(id_);
}

void X10ApiSerial::speedControl(uint8_t id_, int speed)
{

    x10_api_base_.speedControl(id_, speed);
}

void X10ApiSerial::Motor_stop(uint8_t id_)
{

    x10_api_base_.Motor_stop(id_);
}

void X10ApiSerial::Motor_state2(uint8_t id_)
{

    x10_api_base_.Motor_state2(id_);
}
