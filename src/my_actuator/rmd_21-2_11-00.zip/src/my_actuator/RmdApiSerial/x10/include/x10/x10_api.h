/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * Author : Vaibhav
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file x10_api_base.h
 * @author Vaibhav
 * @brief
 * @date 2023-02-17
 *
 *
 */

#ifndef __X10_X10_API_H__
#define __X10_X10_API_H__

#include "base/x10_api_base.h"


class X10ApiSerial
{
private:
    /* data */
public:
    X10ApiSerial(/* args */);
    ~X10ApiSerial();

    
};

#endif