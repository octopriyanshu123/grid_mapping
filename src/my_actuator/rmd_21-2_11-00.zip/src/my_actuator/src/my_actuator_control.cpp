/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved.
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 *
 *
 * @file my_actuator_control.cpp
 * @author Charith
 * @brief
 * @date 2023-02-16
 *
 *
 */

#include "my_actuator/my_actuator_control.h"
#include <unistd.h>
my_actuator_control::my_actuator_control(ros::NodeHandle nh)
{
    /**
     * @brief Constructor
     * @return None
     */
    nh_ = nh;

    init_teleop_ = false;

    act1_enabled_ = false;
    act2_enabled_ = false;
    act3_enabled_ = false;
    act4_enabled_ = false;
	velocity_scale_ = 40;
    error_[0] = "NO Error [Radhe Radhe]";
    error_[2] = "Motor Stalled [Critical]";
    error_[4] = "Low Pressure [Donno Dude]";
    error_[8] = " Over Voltage [Moderate]";
    error_[16] = "Over Current [Critical]";
    error_[64] = "Power Overrun [Moderate]";
    error_[256] = "Speeding [Moderate]";
    error_[512] = "Empty Error 1";
    error_[1024] = "Empty Error 2";
    error_[2048] = "Empty Error 3";
    error_[4096] = "Very High Temperature [Moderate]";
    error_[8192] = "Encoder Calibration Error [Moderate]";
    vitals *health = new vitals();

    toggle_joy_flag_ = -1;

    act_api_ = new X10ApiSerial(); // add what all info do u want to initialize

    geometry_msgs::Twist vel;
    get_params();

    /// initialize the subscribers, publishers and services
    init_subs_pubs_srvs();

    init_actuators();

    joy_reader_timer_ = nh_.createTimer(ros::Duration(0.01), &my_actuator_control::steer_calc_callback_, this);
    health_timer_ = nh_.createTimer(ros::Duration(2), &my_actuator_control::health_callback_, this);
}
my_actuator_control::~my_actuator_control()
{
    /**
     * @brief Destructor
     * @return None
     */
    // delete joy_reader_timer_;
    /// stop the timers
    ROS_INFO("%s: Shutting down", log_header_.c_str());
}
void my_actuator_control::get_params()
{
    /**
     * @brief Get the parameters from the parameter server
     * @return None
     */
    nh_.param<int>("/my_actuator/right_front_wheel/id", right_front_wheel_id_, 2);
    nh_.param<int>("/my_actuator/left_front_wheel/id", left_front_wheel_id_, 1);
    nh_.param<int>("/my_actuator/right_rear_wheel/id", right_rear_wheel_id_, 3);
    nh_.param<int>("/my_actuator/left_rear_wheel/id", left_rear_wheel_id_, 4);
    nh_.param<int>("/my_actuator/right_front_wheel/dir", right_front_wheel_dir_, 1);
    nh_.param<int>("/my_actuator/left_front_wheel/dir", left_front_wheel_dir_, -1);
    nh_.param<int>("/my_actuator/right_rear_wheel/dir", right_rear_wheel_dir_, 1);
    nh_.param<int>("/my_actuator/left_rear_wheel/dir", left_rear_wheel_dir_, -1);
    nh_.param<double>("/my_actuator/wheel_base", WHEEL_BASE_, 0.2913);
    nh_.param<double>("/my_actuator/wheel_radius", WHEEL_RADIUS_, 0.0525);
    ///nh_.param<int>("/my_actuator/velocity_scale", velocity_scale_, 40);

    if (!nh_.getParam("/my_actuator/right_front_wheel/id", right_front_wheel_id_))
    {
        right_front_wheel_id_ = 2;
        ROS_WARN("%s Right Front wheel motor id param not found, using the default value: %d", log_header_.c_str(),
                 right_front_wheel_id_);
    }
    if (!nh_.getParam("/my_actuator/left_front_wheel/id", left_front_wheel_id_))
    {
        left_front_wheel_id_ = 1;
        ROS_WARN("%s left Front wheel motor id param not found, using the default value: %d", log_header_.c_str(),
                 left_front_wheel_id_);
    }
    if (!nh_.getParam("/my_actuator/right_rear_wheel/id", right_rear_wheel_id_))
    {
        right_rear_wheel_id_ = 3;
        ROS_WARN("%s Right rear wheel motor id param not found, using the default value: %d", log_header_.c_str(),
                 right_rear_wheel_id_);
    }
    if (!nh_.getParam("/my_actuator/left_rear_wheel/id", left_rear_wheel_id_))
    {
        left_rear_wheel_id_ = 4;
        ROS_WARN("%s Left rear wheel motor id param not found, using the default value: %d", log_header_.c_str(),
                 left_rear_wheel_id_);
    }

    if (!nh_.getParam("/my_actuator/right_front_wheel/dir", right_front_wheel_dir_))
    {
        right_front_wheel_dir_ = 1;
        ROS_WARN("%s Right Front wheel motor dir param not found, using the default value: %d", log_header_.c_str(),
                 right_front_wheel_dir_);
    }
    if (!nh_.getParam("/my_actuator/left_front_wheel/dir", left_front_wheel_dir_))
    {
        left_front_wheel_dir_ = -1;
        ROS_WARN("%s left Front wheel motor dir param not found, using the default value: %d", log_header_.c_str(),
                 left_front_wheel_dir_);
    }
    if (!nh_.getParam("/my_actuator/right_rear_wheel/dir", right_rear_wheel_dir_))
    {
        right_rear_wheel_dir_ = 1;
        ROS_WARN("%s Right rear wheel motor dir param not found, using the default value: %d", log_header_.c_str(),
                 right_rear_wheel_dir_);
    }
    if (!nh_.getParam("/my_actuator/left_rear_wheel/dir", left_rear_wheel_dir_))
    {
        left_rear_wheel_dir_ = -1;
        ROS_WARN("%s Left rear wheel motor dir param not found, using the default value: %d", log_header_.c_str(),
                 left_rear_wheel_dir_);
    }

    if (!nh_.getParam("/my_actuator/wheel_base", WHEEL_BASE_))
    {
        WHEEL_BASE_ = 0.2913;
        ROS_WARN("%s Wheel Base param not found, using the default value: %f", log_header_.c_str(),
                 WHEEL_BASE_);
    }
    if (!nh_.getParam("/my_actuator/wheel_radius", WHEEL_RADIUS_))
    {
        WHEEL_RADIUS_ = 0.0525;
        ROS_WARN("%s Wheel Radius dir param not found, using the default value: %f", log_header_.c_str(),
                 WHEEL_RADIUS_);
    }
  


    motor_ids.push_back(left_front_wheel_dir_);
    motor_ids.push_back(right_front_wheel_dir_);
    motor_ids.push_back(right_rear_wheel_dir_);
    motor_ids.push_back(left_rear_wheel_dir_);
    sort(motor_ids.begin(), motor_ids.end());
}
void my_actuator_control::init_subs_pubs_srvs()
{
    /**
     * @brief Initialize the subscribers, publishers, services and clients
     * @return none
     */

    joy_sub_ = nh_.subscribe("/skid_steer/cmd_vel", 10, &my_actuator_control::joy_callback, this);
    joy_sub_real = nh_.subscribe<sensor_msgs::Joy>("/joy", 10, &my_actuator_control::get_joy, this);

    toggle_joy_topic_ = "/toggle_joy";
    toggle_joy_sub_ = nh_.subscribe(toggle_joy_topic_, 1,
                                    &my_actuator_control::toggle_joy_callback_, this);

    init_teleop_srv_ = nh_.advertiseService("/crawler_control_node/init_teleop",
                                            &my_actuator_control::init_teleop_callback, this);
    stop_teleop_srv_ = nh_.advertiseService("/crawler_control_node/stop_teleop",
                                            &my_actuator_control::stop_teleop_callback, this);
    stop_motors_srv_ = nh_.advertiseService("/crawler_control_node/stop_motors",
                                            &my_actuator_control::stop_motors_callback, this);
}

bool my_actuator_control::init_teleop_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res)
{
    /**
     * @brief Initialize the teleoperation
     * @param req
     * @type std_srvs::TriggerRequest
     * @param res
     * @type std_srvs::TriggerResponse
     * @return true
     */

    init_teleop_ = true;
    init_actuators();
    res.success = true;
    res.message = "teleop started";
    return true;
}
bool my_actuator_control::stop_teleop_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res)
{
    /**
     * @brief Stop the teleoperation
     * @param req
     * @type std_srvs::TriggerRequest
     * @param res
     * @type std_srvs::TriggerResponse
     * @return true
     */

    init_teleop_ = false;
    ROS_INFO("%sStopping teleop", log_header_.c_str());
    for (auto &it : motor_ids)
    {
        stop_actuators(it);
    }
    res.success = true;
    res.message = "teleop stopped";
    return true;
}

bool my_actuator_control::stop_motors_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res)
{
    /**
     * @brief Stop the teleoperation
     * @param req
     * @type std_srvs::TriggerRequest
     * @param res
     * @type std_srvs::TriggerResponse
     * @return true
     */

    ROS_INFO("%sStopping motors", log_header_.c_str());

    // init_teleop_ = false;
    // res.success = true;
    // res.message = "teleop stopped";
    return true;
}
void my_actuator_control::init_actuators()
{
    /**
     * @brief Initialize the actuators
     * @return none
     */

    int setVEL, res;

    // for (auto &it : motor_ids)
    // {
    act_api_->rmdX10_init();
    // if (res == 1)
    // {
    //     ROS_INFO("%s Actuator %d Initialized", log_header_.c_str(), it);
    // }
    // else
    // {
    //     ROS_ERROR("%s  Actuator %d NOT Initialized", log_header_.c_str(), it);
    // }
    // }

    // for (auto &it : motor_ids)
    // {
    //     // 1. Current loop mode (0x01).
    //     // 2. Speed loop mode (0x02).
    //     // 3. Position loop mode (0x03).
    //     setVEL = act_api_->Motor_mode(it, 2);
    //     if (setVEL == 0)
    //     {
    //         ROS_INFO("%s Actuator %d set to VELOCITY", log_header_.c_str(), it);
    //     }
    //     else
    //     {
    //         ROS_ERROR("%s Actuator %d set to VELOCITY failed", log_header_.c_str(), it);
    //     }
    // }
}
void my_actuator_control::stop_actuators(int id)
{
    /**
     * @brief Enable the actuator of given id
     * @param id, id of the actuator
     * @type int
     * @return none
     */
    if (init_teleop_)
    {
        // int res;
        // for (auto &it : motor_ids)
        // {
        //     res = act_api_->Motor_stop(it);
        //     if (res == 1)
        //     {
        //         ROS_INFO("%s Actuator %d Stopped", log_header_.c_str(), it);
        //     }
        //     else
        //     {
        //         ROS_ERROR("%s  Actuator %d NOT Stopped", log_header_.c_str(), it);
        //     }
        // }
    }
}
void my_actuator_control::run_actuator(int id, double curr_vel)
{
    if (init_teleop_)
    {
        // res = act_api_->speedControl(unsigned short F_ID, unsigned int speedControl);
// ROS_INFO("final velocity  %f",curr_vel); 
        act_api_->speedControl(id, (int)curr_vel);
    }
}

void my_actuator_control::joy_callback(const geometry_msgs::Twist &msg)
{

    vel.linear.x = msg.linear.x;
    vel.angular.z = msg.angular.z;
}
void my_actuator_control::toggle_joy_callback_(const std_msgs::Bool::ConstPtr &msg)
{

    toggle_joy_flag_ = msg->data;
}
void my_actuator_control::get_joy(const sensor_msgs::Joy::ConstPtr &joy)
{
    /**
     * @brief Callback for the joystick
     * @param joy
     * @type sensor_msgs::Joy
     * @return none
     */

    if (init_teleop_) //&& toggle_joy_flag_ == 0)
    {

        if (joy->buttons[JoyStick::ACT1_2_ON_OFF])
        {
            act1_sw_ = !act1_sw_;
            act2_sw_ = !act2_sw_;
            ROS_INFO("In act2");
            ROS_INFO("In act1");
        }
        else if (joy->buttons[JoyStick::ACT3_4_ON_OFF])
        {
            act3_sw_ = !act3_sw_;
            act4_sw_ = !act4_sw_;
            ROS_INFO("In act4");
            ROS_INFO("In act3");
        }
        else
        {
            act1_sw_ = false;
            act2_sw_ = false;
            act3_sw_ = false;
            act4_sw_ = false;
        }
    }
}
void my_actuator_control::steer_calc_callback_(const ros::TimerEvent &)
{
    /**
     * @brief ROS timer thread callback for reading joy state and calling the corresponding methods
     * @param not used
     * @type ros::TimerEvent
     * @return none
     */
    if (init_teleop_)
    {

        if (vel.linear.x == 0 && vel.angular.z == 0)
        {
            // set vel zero
            run_actuator(left_front_wheel_id_, 0);
            run_actuator(right_front_wheel_id_, 0);
            run_actuator(right_rear_wheel_id_, 0);
            run_actuator(left_rear_wheel_id_, 0);
        }
        else
        {
            velocity_left_cmd_ = ((vel.linear.x - vel.angular.z * WHEEL_BASE_ / 2.0) / WHEEL_RADIUS_)* velocity_scale_;
;
            // ROS_INFO("%left velocity",velocity_left_cmd_);

            velocity_right_cmd_ = ((vel.linear.x + vel.angular.z * WHEEL_BASE_ / 2.0) / WHEEL_RADIUS_) * velocity_scale_;


            // send data to actuator

            // run_actuator(1, velocity_left_cmd_ * 300);
            // ROS_INFO("Vel: %f", velocity_left_cmd_ * 300);
            run_actuator(left_front_wheel_id_,  velocity_left_cmd_ * left_front_wheel_dir_);
            run_actuator(right_front_wheel_id_, velocity_right_cmd_ * right_front_wheel_dir_);
            run_actuator(right_rear_wheel_id_,  velocity_right_cmd_ * right_rear_wheel_dir_ );
            run_actuator(left_rear_wheel_id_,  velocity_left_cmd_ * left_rear_wheel_dir_);
            // ROS_INFO("Motor id:%d right velocity  %f",right_front_wheel_id_,velocity_right_cmd_);        
	}
    }
}
void my_actuator_control::health_callback_(const ros::TimerEvent &)
{
    for (auto &it : motor_ids)
    {
        get_vitals(it);
        // ROS_INFO("Motor : %d /n Temperature: %d Error: %s", it, health[it - 1].temperature, error_[health[it - 1].error]);
    }
}
void my_actuator_control::get_vitals(int id)
{
//     float ret[3];
//     0 : temp 1 : voltage 2 : error
//                                  ret = act_api_->vitals(id);
//     health[id - 1].temperature = (int)ret[0];
//     health[id - 1].voltage = ret[1];
//     health[id - 1].error = (int)ret[2];
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "crawler_control_node");
    ROS_INFO("[CrawlerTeleOpNode]: Starting Node");
    ros::NodeHandle nh;
    my_actuator_control crawler_teleop(nh);

    try
    {
        ros::spin();
    }
    catch (std::exception &e)
    {
        ROS_ERROR("%sException thrown: %s", crawler_teleop.log_header_.c_str(), e.what());
    }
    return 0;
}
