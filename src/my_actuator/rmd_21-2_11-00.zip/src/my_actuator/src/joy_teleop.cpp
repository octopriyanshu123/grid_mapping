#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include "std_msgs/Bool.h"

class skidsteer_teleop
{
public:
    skidsteer_teleop();
    int lin_inc = 2;
    int ang_inc = 4;

private:
    void joyCallback(const sensor_msgs::Joy::ConstPtr &joy);
    void toggleJoyCallback(const std_msgs::Bool::ConstPtr &msg);

    ros::NodeHandle nh_;
    int toggle_joy_flag_ = -1;
    int linear_, angular_;
    int l_inc_, a_inc_, l_dec_, a_dec_;
    ros::Publisher vel_pub_;
    ros::Subscriber joy_sub_;
    ros::Subscriber toggle_joy_sub_;

    ros::Publisher vel_gui_pub_;
};

skidsteer_teleop::skidsteer_teleop() : linear_(3),
                                       angular_(0),
                                       l_inc_(3),
                                       a_inc_(0),
                                       l_dec_(1),
                                       a_dec_(2)
{

    nh_.param("axis_linear", linear_, linear_);
    nh_.param("axis_angular", angular_, angular_);
    // nh_.param("scale_angular", a_scale_, a_scale_);
    // nh_.param("scale_linear", l_scale_, l_scale_);

    vel_pub_ = nh_.advertise<geometry_msgs::Twist>("skid_steer/cmd_vel", 1);

    joy_sub_ = nh_.subscribe<sensor_msgs::Joy>("/joy", 10, &skidsteer_teleop::joyCallback, this);
    toggle_joy_sub_ = nh_.subscribe<std_msgs::Bool>("/toggle_joy", 10, &skidsteer_teleop::toggleJoyCallback, this);
}

void skidsteer_teleop::toggleJoyCallback(const std_msgs::Bool::ConstPtr &msg)
{

    toggle_joy_flag_ = msg->data;
}

void skidsteer_teleop::joyCallback(const sensor_msgs::Joy::ConstPtr &joy)
{
    // ROS_INFO("toggle: %d craweler", toggle_joy_flag_);

    // if(toggle_joy_flag_ == 0){
    // ROS_INFO("inside: %d craweler", toggle_joy_flag_);

    geometry_msgs::Twist twist;
    lin_inc = lin_inc + 1 * joy->buttons[l_inc_];
    ang_inc = ang_inc + 1 * joy->buttons[a_inc_];
    lin_inc = lin_inc - 1 * joy->buttons[l_dec_];
    ang_inc = ang_inc - 1 * joy->buttons[a_dec_];

    if (lin_inc < 0)
    {
        lin_inc = 0;
    }

    if (ang_inc < 0)
    {
        ang_inc = 0;
    }

    if (joy->buttons[l_inc_] || joy->buttons[a_inc_] || joy->buttons[l_dec_] || joy->buttons[a_dec_])
    {
        ROS_INFO("linear: %d , angular: %d", lin_inc, ang_inc);
    }
    twist.angular.z = ang_inc * joy->axes[angular_];
    twist.linear.x = lin_inc * joy->axes[linear_];

    vel_pub_.publish(twist);

    // }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "teleop_joy");
    skidsteer_teleop teleop_skidsteer;

    ros::spin();
}
