/**
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * Copyright (C) 2023 Octobotics Tech Pvt. Ltd. All Rights Reserved. 
 * Do not remove this copyright notice.
 * Do not use, reuse, copy, merge, publish, sub-license, sell, distribute or modify this code - except without explicit,
 * written permission from Octobotics Tech Pvt. Ltd.
 * Contact connect@octobotics.tech for full license information.
 * -------------------------------------------- COPYRIGHT NOTICE ---------------------------------------------------
 * 
 * 
 * @file my_actuator_control.h
 * @author Charith 
 * @brief 
 * @date 2023-02-15
 * 
 * 
 */

#include "ros/ros.h"
#include "sensor_msgs/JointState.h"
#include "sensor_msgs/Joy.h"
#include "std_srvs/Trigger.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Bool.h"
#include <cstdlib>
#include <geometry_msgs/Twist.h>
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <bits/stdc++.h>
#include "rmd/x10_api.h"

using namespace std;
enum JoyStick
{
    /// axes
    FORWARD_BACKWARD = 3,
    LEFT_RIGHT = 0,

    // buttons
    ACT1_2_ON_OFF = 4,
    ACT3_4_ON_OFF = 5
};

struct vitals
{
    float voltage;
    int error;
    int temperature;
};

class my_actuator_control
{

public:
   
   
       my_actuator_control(ros::NodeHandle nh_);

    
    
    ~my_actuator_control();

    /**
     * @brief Get the parameters from the parameter server
     * @return none
     */
    void get_params();

    /**
     * @brief Initialize the subscribers, publishers, services
     * @return none
     */
    void init_subs_pubs_srvs();

    /**
     * @brief allback for the init teleop service
     * @return none
     */
    bool init_teleop_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res);

    /**
     * @brief Callback for the stop teleop service
     * @param req, request message
     * @param res, response message
     * @return success or failure
     */
    bool stop_teleop_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res);
     /**
     * @brief Callback for the stop motors service
     * @param req, request message
     * @param res, response message
     * @return success or failure
     */

    bool stop_motors_callback(std_srvs::TriggerRequest &req, std_srvs::TriggerResponse &res);
    /**
     * @brief Initialize the actuators
     * @return none
     */

    void init_actuators();
    /**
     * @brief Stops the actuator with the given id
     * @param id, id of the actuator
     * @return none
     */
    void stop_actuators(int id);
    /**
     * @brief Run the actuator with the given id at the given velocity
     * @param id, id of the actuator
     * @param vel, direction of the actuator to be multiplied with the current velocity
     * @return none
     */
    void run_actuator(int id, double vel);
    /**
     * @brief Callback for the joystick
     * @param joy, joystick message
     * @return none
     */
    void joy_callback(const geometry_msgs::Twist &msg);
    /**
     * @brief Callback to get joystick data
     * @param msg, joint state message
     * @return none
     */

    void get_joy(const sensor_msgs::Joy::ConstPtr &joy);
    /**
     * @brief Callback for the actuator state
     * @param msg, joint state message
     * @return none
     */
    void actuator_state_callback(const sensor_msgs::JointState::ConstPtr &msg);

    /**
     * @brief Callback for the init teleop service
     * @param req, request message
     * @param res, response message
     * @return success or failure
     */

    void toggle_joy_callback_(const std_msgs::Bool::ConstPtr &msg);

    /**
     * @brief Checks vitals of the motor
     * @param id, motor ID
     * @return none
     */
    void get_vitals(int id);

    /// velocity control parameters
    double curr_vel;

    /// log header string
    std::string log_header_;

    bool init_teleop_;
    geometry_msgs::Twist vel;

private:
    /// node specific parameters
    ros::NodeHandle nh_;

    X10ApiSerial *act_api_;

    /// subscribers
    ros::Subscriber joy_sub_;
    ros::Subscriber actuator_states_sub_;
    ros::Subscriber joy_sub_real;
    std::string toggle_joy_topic_;
    ros::Subscriber toggle_joy_sub_;
    
    /// services
    ros::ServiceServer init_teleop_srv_;
    ros::ServiceServer stop_teleop_srv_;
    ros::ServiceServer stop_motors_srv_;
    
    vector<int> motor_ids;
    vector<vitals> *health;

    map<int, string> error_;


    int toggle_joy_flag_;

    int velocity_scale_;

    int right_front_wheel_id_;
    int left_front_wheel_id_;
    int right_rear_wheel_id_;
    int left_rear_wheel_id_;
    
    int right_front_wheel_dir_;
    int left_front_wheel_dir_;
    int right_rear_wheel_dir_;
    int left_rear_wheel_dir_;
    int velocity_scake;
    /// actuator enable/disable flags
    bool act1_sw_;
    bool act2_sw_;
    bool act3_sw_;
    bool act4_sw_;
    bool act1_enabled_;
    bool act2_enabled_;
    bool act3_enabled_;
    bool act4_enabled_;

    float velocity_left_cmd_;
    float velocity_right_cmd_;

    double WHEEL_BASE_;
    double WHEEL_RADIUS_;

    ros::Timer joy_reader_timer_;
    ros::Timer health_timer_;

    void steer_calc_callback_(const ros::TimerEvent &event);
    void health_callback_(const ros::TimerEvent &event);
};
